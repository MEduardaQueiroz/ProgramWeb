require('dotenv').config();
const mongoose = require('mongoose');
const Item = require('./models/Itennpm start'); // Certifique-se de que o caminho está correto

// Função principal de seed
async function seed() {
  try {
    // Valida a URL do MongoDB antes de conectar
    const mongoUri = process.env.MONGODB_URI || 'mongodb+srv://renanzikazk:Re88522733@cluster0.y2mno.mongodb.net/hamburgueria?retryWrites=true&w=majority';
    if (!mongoUri) {
      throw new Error('MONGODB_URI não definido no arquivo .env ou como fallback');
    }

    // Conecta ao MongoDB
    await mongoose.connect(mongoUri, {
      serverSelectionTimeoutMS: 20000,
      connectTimeoutMS: 20000,
    });
    console.log('Conectado ao MongoDB Atlas');

    // Limpa a coleção existente
    await Item.deleteMany({});
    console.log('Coleção "items" limpa');

    // Lista de itens a serem inseridos
    const items = [
      { name: 'Super Clássico', price: 20.00, image: 'https://d3sn2rlrwxy0ce.cloudfront.net/Stacker_Duplo_Bacon-thumb-cupom-m-d.png?mtime=20220825142919&focal=none', description: 'Delicioso hambúrguer feito com ingredientes frescos.' },
      { name: 'Chicken Junior', price: 15.00, image: 'https://d3sn2rlrwxy0ce.cloudfront.net/Chicken-Jr.png?mtime=20230703115832&focal=none', description: 'Delicioso hambúrguer de frango.' },
      { name: 'Salada Suprema', price: 35.00, image: 'https://d3sn2rlrwxy0ce.cloudfront.net/_800x600_crop_center-center_none/whopper_jr.png?mtime=20231010141030&focal=none&tmtime=20241024164410', description: 'Delicioso hambúrguer feito de saladas com agrotóxicos.' },
      { name: 'Pirilampus', price: 45.00, image: 'https://d3sn2rlrwxy0ce.cloudfront.net/CBK-thumb-cupom-m-d-1.png?mtime=20221129151429&focal=none', description: 'Feito com a maior alegria da floresta.' },
      { name: 'Hambúrguer Unidos', price: 35.00, image: 'https://d3sn2rlrwxy0ce.cloudfront.net/chicken-duplo-thumb.png?mtime=20210916143308&focal=none', description: 'Delicioso hambúrguer feito para você e sua parceira.' },
      { name: 'Mega Chicken Artesanal', price: 32.00, image: 'https://d3sn2rlrwxy0ce.cloudfront.net/BK-Chicken-Crispy-thumb.png?mtime=20230125075509&focal=none', description: 'Explosão de sabores feito pra você.' },
      { name: 'Vaqueijada Artesanal', price: 22.00, image: 'https://d3sn2rlrwxy0ce.cloudfront.net/Rodeio-thumb.png?mtime=20230125075349&focal=none', description: 'Delicioso hambúrguer com a mistura dos dois mundos.' },
      { name: 'Aviões de Papel', price: 30.00, image: 'https://d3sn2rlrwxy0ce.cloudfront.net/_800x600_crop_center-center_none/BK_Taste_1.0.png?mtime=20250108095524&focal=none&tmtime=20250108105909', description: 'Coma esse delicioso hambúrguer e vá para as alturas.' }
    ];

    // Insere os itens e verifica o resultado
    const insertedItems = await Item.insertMany(items);
    console.log(`Itens adicionados ao cardápio: ${insertedItems.length} itens inseridos`);
    console.log('IDs dos itens inseridos:', insertedItems.map(item => item._id));

  } catch (err) {
    console.error('Erro ao executar o seed:', err.message);
    throw err; // Para debug, mantém o erro visível
  } finally {
    // Fecha a conexão mesmo em caso de erro
    if (mongoose.connection.readyState !== 0) {
      await mongoose.connection.close();
      console.log('Conexão com MongoDB fechada');
    }
  }
}

// Executa a função e trata erros de nível superior
seed()
  .then(() => console.log('Seed concluído com sucesso'))
  .catch(err => console.error('Erro fatal no seed:', err));