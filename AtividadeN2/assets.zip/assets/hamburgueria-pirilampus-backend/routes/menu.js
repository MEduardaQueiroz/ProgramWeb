// routes/menu.js
const express = require('express');
const router = express.Router();
const Item = require('../models/Iten');

router.get('/', async (req, res) => {
  try {
    console.log('Acessando rota /menu');
    const menuItems = await Item.find();
    console.log('Itens encontrados:', menuItems);
    res.render('menu', { 
      title: 'Cardápio - Hamburgueria Pirilampus', 
      menuItems,
      user: req.user
    });
  } catch (err) {
    console.error('Erro ao carregar o cardápio:', err);
    res.status(500).send('Erro interno ao carregar o cardápio');
  }
});

module.exports = router;