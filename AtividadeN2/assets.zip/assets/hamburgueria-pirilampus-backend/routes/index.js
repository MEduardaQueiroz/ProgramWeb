// routes/index.js
const express = require('express');
const router = express.Router();

// Rota inicial - renderiza a página inicial com o usuário autenticado (se houver)
router.get('/', (req, res) => {
  res.render('index', { title: 'Hamburgueria Pirilampus', user: req.user });
});

module.exports = router;