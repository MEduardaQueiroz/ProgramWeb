// routes/cart.js
const express = require('express');
const router = express.Router();
const Cart = require('../models/Cart');
const Item = require('../models/Iten');

router.get('/', async (req, res) => {
  if (!req.user) return res.redirect('/users/login');
  try {
    let cart = await Cart.findOne({ userId: req.user._id }).populate('items.itemId');
    if (!cart) cart = { items: [] };
    res.render('cart', { title: 'Carrinho', cart: cart.items, user: req.user });
  } catch (err) {
    console.error('Erro ao carregar o carrinho:', err);
    res.status(500).send('Erro interno ao carregar o carrinho');
  }
});

router.post('/add', async (req, res) => {
  if (!req.user) return res.redirect('/users/login');
  try {
    const { itemId } = req.body;
    console.log('Item ID recebido para adicionar:', itemId);
    let cart = await Cart.findOne({ userId: req.user._id });
    if (!cart) {
      cart = new Cart({ userId: req.user._id, items: [] });
    }
    const itemIndex = cart.items.findIndex(i => i.itemId.toString() === itemId);
    if (itemIndex > -1) {
      cart.items[itemIndex].quantity += 1;
    } else {
      cart.items.push({ itemId });
    }
    await cart.save();
    console.log('Carrinho atualizado (add):', cart);
    res.redirect('/menu');
  } catch (err) {
    console.error('Erro ao adicionar ao carrinho:', err);
    res.status(500).send('Erro interno ao adicionar ao carrinho');
  }
});

router.post('/remove', async (req, res) => {
  if (!req.user) return res.redirect('/users/login');
  try {
    const { itemId } = req.body;
    console.log('Item ID recebido para remover:', itemId);
    let cart = await Cart.findOne({ userId: req.user._id });
    if (cart) {
      const itemIndex = cart.items.findIndex(i => i.itemId.toString() === itemId);
      if (itemIndex > -1) {
        cart.items.splice(itemIndex, 1);
        await cart.save();
        console.log('Item removido, carrinho atualizado:', cart);
      }
    }
    res.redirect('/cart');
  } catch (err) {
    console.error('Erro ao remover do carrinho:', err);
    res.status(500).send('Erro interno ao remover do carrinho');
  }
});

router.post('/decrease', async (req, res) => {
  if (!req.user) return res.redirect('/users/login');
  try {
    const { itemId } = req.body;
    console.log('Item ID recebido para diminuir:', itemId);
    let cart = await Cart.findOne({ userId: req.user._id });
    if (cart) {
      const itemIndex = cart.items.findIndex(i => i.itemId.toString() === itemId);
      if (itemIndex > -1) {
        if (cart.items[itemIndex].quantity > 1) {
          cart.items[itemIndex].quantity -= 1;
        } else {
          cart.items.splice(itemIndex, 1); // Remove se quantidade chegar a 0
        }
        await cart.save();
        console.log('Quantidade diminuída, carrinho atualizado:', cart);
      }
    }
    res.redirect('/cart');
  } catch (err) {
    console.error('Erro ao diminuir quantidade:', err);
    res.status(500).send('Erro interno ao diminuir quantidade');
  }
});

router.post('/increase', async (req, res) => {
  if (!req.user) return res.redirect('/users/login');
  try {
    const { itemId } = req.body;
    console.log('Item ID recebido para aumentar:', itemId);
    let cart = await Cart.findOne({ userId: req.user._id });
    if (!cart) {
      cart = new Cart({ userId: req.user._id, items: [] });
    }
    const itemIndex = cart.items.findIndex(i => i.itemId.toString() === itemId);
    if (itemIndex > -1) {
      cart.items[itemIndex].quantity += 1;
    } else {
      cart.items.push({ itemId });
    }
    await cart.save();
    console.log('Quantidade aumentada, carrinho atualizado:', cart);
    res.redirect('/cart');
  } catch (err) {
    console.error('Erro ao aumentar quantidade:', err);
    res.status(500).send('Erro interno ao aumentar quantidade');
  }
});

module.exports = router;