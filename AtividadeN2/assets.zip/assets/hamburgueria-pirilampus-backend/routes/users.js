const express = require('express');
const router = express.Router();
const bcrypt = require('bcrypt');
const passport = require('passport');
const User = require('../models/user');

// Middleware para logs de depuração (opcional)
const debugLog = (req, message) => {
  console.log(`[${req.method} ${req.path}] ${message}`);
};

// GET /login
router.get('/login', (req, res) => {
  debugLog(req, 'Renderizando página de login');
  res.render('login', { title: 'Login - Hamburgueria Pirilampus' });
});

// POST /login
router.post('/login', (req, res, next) => {
  debugLog(req, 'Tentativa de login com dados: ' + JSON.stringify(req.body));
  passport.authenticate('local', {
    successRedirect: '/menu',
    failureRedirect: '/users/login',
    failureFlash: true
  })(req, res, next);
});

// GET /register
router.get('/register', (req, res) => {
  debugLog(req, 'Renderizando página de registro');
  res.render('register', { title: 'Cadastro - Hamburgueria Pirilampus' });
});

// POST /register
router.post('/register', async (req, res) => {
  try {
    const { username, password } = req.body;
    debugLog(req, `Tentativa de cadastro: username=${username}`);

    // Validação mais robusta
    if (!username || !password) {
      req.flash('error', 'Usuário e senha são obrigatórios');
      debugLog(req, 'Campos obrigatórios ausentes');
      return res.redirect('/users/register');
    }
    if (password.length < 6) {
      req.flash('error', 'A senha deve ter pelo menos 6 caracteres');
      debugLog(req, 'Senha muito curta');
      return res.redirect('/users/register');
    }

    const existingUser = await User.findOne({ username });
    if (existingUser) {
      req.flash('error', 'Usuário já existe');
      debugLog(req, `Usuário ${username} já existe`);
      return res.redirect('/users/register');
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const user = new User({ username, password: hashedPassword });
    await user.save();
    debugLog(req, `Usuário ${username} cadastrado com sucesso`);
    req.flash('success', 'Cadastro realizado com sucesso! Faça login.');
    res.redirect('/users/login');
  } catch (err) {
    console.error('Erro ao cadastrar usuário:', err.message, err.stack);
    req.flash('error', 'Erro interno ao cadastrar');
    res.redirect('/users/register');
  }
});

// GET /logout
router.get('/logout', (req, res, next) => {
  debugLog(req, 'Iniciando logout');
  req.logout((err) => {
    if (err) {
      debugLog(req, 'Erro ao fazer logout: ' + err.message);
      return next(err);
    }
    debugLog(req, 'Logout realizado com sucesso');
    req.flash('success', 'Logout realizado com sucesso!');
    res.redirect('/');
  });
});

module.exports = router;